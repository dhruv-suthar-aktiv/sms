# -*- coding: utf-8 -*-

from . import models, clg_students, clg_professors, sale_order_up_clg
